import json
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')  # Adjust the connection string if needed
db = client['rescue_dogs_db']  # Access the database
collection = db['dogs']  # Access the collection

def load_data_from_json(file_path):
    """Load data from a JSON file and insert it into the MongoDB collection."""
    with open(file_path, 'r') as file:
        data = json.load(file)  # Load the JSON data
        if isinstance(data, list):  # Check if the data is a list
            result = collection.insert_many(data)  # Insert multiple documents
            return [str(id) for id in result.inserted_ids]  # Return the list of inserted IDs
        else:
            raise ValueError("JSON data must be a list of objects.")

if __name__ == "__main__":
    json_file_path = 'data/animals.json'  # Path to your JSON file
    try:
        inserted_ids = load_data_from_json(json_file_path)
        print(f'Dogs inserted with IDs: {inserted_ids}')
    except Exception as e:
        print(f'Error: {e}')
