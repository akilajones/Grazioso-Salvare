import dash
from dash import dcc, html, Input, Output, dash_table
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from pymongo import MongoClient
from bson import ObjectId

# Load data from JSON file
def load_data():
    # Connect to MongoDB
    client = MongoClient('mongodb://localhost:27017/')  # Adjust the connection string if needed
    db = client['rescue_dogs_db']  # Access the database
    collection = db['dogs']  # Access the collection

    # Load data from MongoDB
    data = list(collection.find())  # Retrieve all documents from the collection

    # Convert ObjectId to string and create DataFrame
    for item in data:
        item['_id'] = str(item['_id'])  # Convert ObjectId to string

    df = pd.DataFrame(data)

    # Convert necessary fields to string and handle null values
    df['datetime'] = df['datetime'].astype(str)  # Convert datetime to string
    df['date_of_birth'] = pd.to_datetime(df['date_of_birth'], errors='coerce')  # Convert to datetime
    df['monthyear'] = df['monthyear'].astype(str)  # Convert monthyear to string
    
    # Fill null values with a placeholder or empty string
    df.fillna('', inplace=True)
    
    # Calculate age for each dog based on the date of birth
    current_date = datetime.now()
    df['age'] = (current_date - df['date_of_birth']).dt.days // 365  # Calculate age in years

    # Close the MongoDB connection
    client.close()

    return df

# Define rescue types dynamically based on breed and age
def calculate_rescue_type(row):
    # Define breed groups for each rescue type
    water_rescue_breeds = ['Labrador', 'Chesapeake', 'Newfoundland']  # Substrings for water rescue
    mountain_rescue_breeds = ['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler']
    disaster_tracking_breeds = ['Doberman', 'German Shepherd', 'Golden Retriever', 'Bloodhound', 'Rottweiler']
    
    # Define preferred sex for each rescue type
    preferred_sex_water = 'Intact Female'
    preferred_sex_mountain = 'Intact Male'
    preferred_sex_disaster_tracking = 'Intact Male'
    
    # Define training age ranges (in weeks)
    min_training_age_water = 26  # 26 weeks
    max_training_age_water = 156  # 156 weeks (around 3 years)
    
    min_training_age_mountain = 26  # 26 weeks
    max_training_age_mountain = 156  # 156 weeks (around 3 years)
    
    min_training_age_disaster_tracking = 20  # 20 weeks
    max_training_age_disaster_tracking = 300  # 300 weeks (around 5.7 years)
    
    # Use the age_upon_outcome_in_weeks directly from the row
    dog_age_weeks = row['age_upon_outcome_in_weeks']
    
    # Debugging output
    if row['animal_id'] == "A672540":
        print(f"Processing breed: {row['breed']}, sex: {row['sex_upon_outcome']}, age in weeks: {dog_age_weeks}, id: {row['animal_id']}")
    
    # Check if the dog is suitable for any of the rescue types
    if any(breed in row['breed'] for breed in water_rescue_breeds) and row['sex_upon_outcome'] == preferred_sex_water and min_training_age_water <= dog_age_weeks <= max_training_age_water:
        return 'Water Rescue'
    elif any(breed in row['breed'] for breed in mountain_rescue_breeds) and row['sex_upon_outcome'] == preferred_sex_mountain and min_training_age_mountain <= dog_age_weeks <= max_training_age_mountain:
        return 'Mountain or Wilderness Rescue'
    elif any(breed in row['breed'] for breed in disaster_tracking_breeds) and row['sex_upon_outcome'] == preferred_sex_disaster_tracking and min_training_age_disaster_tracking <= dog_age_weeks <= max_training_age_disaster_tracking:
        return 'Disaster or Individual Tracking'
    else:
        return 'Not Suitable for Rescue'  # Default if no conditions are met

# Initialize the Dash app
app = dash.Dash(__name__)

app.layout = html.Div([
    html.Div([
        html.Img(src="/assets/logo.png", style={'height': '80px', 'margin-right': '20px'}),
        html.H1("Grazioso Salvare Dashboard", style={'display': 'inline-block', 'vertical-align': 'middle'})
    ], style={'display': 'flex', 'align-items': 'center', 'margin-bottom': '20px'}),
    
    dcc.RadioItems(
        id='rescue-type-radio',
        options=[
            {'label': 'Water Rescue', 'value': 'Water Rescue'},
            {'label': 'Mountain or Wilderness Rescue', 'value': 'Mountain or Wilderness Rescue'},
            {'label': 'Disaster or Individual Tracking', 'value': 'Disaster or Individual Tracking'},
        ],
        value=None,  # Default value
        labelStyle={'display': 'block'}  # Display each radio button on a new line
    ),
    
    html.Button('Reset', id='reset-button', n_clicks=0),
    
    dash_table.DataTable(
        id='dogs-table',
        columns=[
            {'name': 'Animal ID', 'id': 'animal_id'},
            {'name': 'Name', 'id': 'name'},
            {'name': 'Animal type', 'id': 'animal_type'},
            {'name': 'Age Upon Outcome', 'id': 'age_upon_outcome'},
            {'name': 'Date of Birth', 'id': 'date_of_birth'},
            {'name': 'Datetime', 'id': 'datetime'},
            {'name': 'Month Year', 'id': 'monthyear'},
            {'name': 'Breed', 'id': 'breed'},
            {'name': 'Outcome Type', 'id': 'outcome_type'},
            {'name': 'Sex Upon Outcome', 'id': 'sex_upon_outcome'},
            {'name': 'Color', 'id': 'color'},
            {'name': 'Rescue Type', 'id': 'rescue_type'}
        ],
        page_size=10,
        style_table={'overflowX': 'auto'},
        row_selectable="single",  # Enable single row selection
        selected_rows=[],  # No row selected by default
        style_data_conditional=[{
            'if': {'state': 'selected'},
            'backgroundColor': '#D2F3FF',  # Highlight selected rows
        }]
    ),
    
    html.Div([
        dcc.Graph(id='geolocation-chart', style={'height': '600px'}),  # Increased height for geolocation chart
        dcc.Graph(id='secondary-chart', style={'height': '400px'}),     # Increased height for secondary chart
    ], style={'display': 'flex', 'justify-content': 'space-between'}),  # Side by side layout

     # Footer Section with "Made by" Text
    html.Div([
        html.P("Made by Akila jones", style={'text-align': 'center', 'margin-top': '20px', 'font-size': '16px'})
    ], style={'margin-top': '40px'})
])

@app.callback(
    [Output('dogs-table', 'data'),
     Output('rescue-type-radio', 'value'),
     Output('geolocation-chart', 'figure'),
     Output('secondary-chart', 'figure')],
    [Input('rescue-type-radio', 'value'),
     Input('reset-button', 'n_clicks'),
     Input('dogs-table', 'selected_rows')]
)
def update_dashboard(selected_rescue_type, n_clicks, selected_rows):
    df = load_data()
    df['rescue_type'] = df.apply(calculate_rescue_type, axis=1)
    
    # Get the triggering input
    ctx = dash.callback_context
    triggered_input = ctx.triggered[0]['prop_id'].split('.')[0] if ctx.triggered else None

    # Reset Button Logic
    if triggered_input == 'reset-button' and n_clicks > 0:
        # Reset to show full dataset and clear selections
        full_geolocation_fig = px.scatter_mapbox(
            df, lat='location_lat', lon='location_long', hover_name='name',
            title='Geolocation of Dogs', zoom=10, height=600
        )
        full_geolocation_fig.update_layout(mapbox_style="open-street-map")
        full_geolocation_fig.update_traces(
            marker=dict(size=10, color='blue', opacity=0.7)  # Custom marker properties
        )

        full_secondary_fig = px.pie(df, names='breed', title='Breed Distribution', height=400)

        return df.to_dict('records'), None, full_geolocation_fig, full_secondary_fig

    # Filter by Rescue Type
    if selected_rescue_type and triggered_input != 'dogs-table':
        filtered_df = df[df['rescue_type'] == selected_rescue_type]
    else:
        filtered_df = df

    # Row Selection Logic
    if triggered_input == 'dogs-table' and selected_rows:
        selected_data = df.iloc[selected_rows[0]]
        filtered_df = df[df['animal_id'] == selected_data['animal_id']]

    # Geolocation Chart
    if not filtered_df.empty:
        geolocation_fig = px.scatter_mapbox(
            filtered_df, lat='location_lat', lon='location_long', hover_name='name',
            title='Geolocation of Dogs', zoom=10, height=600
        )
        geolocation_fig.update_layout(mapbox_style="open-street-map")
        geolocation_fig.update_traces(
            marker=dict(size=12, color='red', opacity=0.8, symbol='circle')  # Custom marker properties
        )
    else:
        geolocation_fig = go.Figure()
        geolocation_fig.add_annotation(text="No Data Available", showarrow=False, font=dict(size=20))

    # Secondary Chart (Breed Distribution)
    if not filtered_df.empty:
        secondary_fig = px.pie(filtered_df, names='breed', title='Breed Distribution', height=400)
    else:
        secondary_fig = go.Figure()
        secondary_fig.add_annotation(text="No Data Available", showarrow=False, font=dict(size=20))

    return filtered_df.to_dict('records'), selected_rescue_type, geolocation_fig, secondary_fig





def update_charts_on_selection(selected_rows):
    df = load_data()
    
    # Calculate rescue type dynamically and add it to the DataFrame
    df['rescue_type'] = df.apply(calculate_rescue_type, axis=1)
    
    # Handle selection
    if selected_rows:
        selected_data = df.iloc[selected_rows[0]]  # Only one row is selectable
        filtered_df = df[df['animal_id'] == selected_data['animal_id']]
    else:
        filtered_df = df  # Default to full data if no row is selected
    
    # Geolocation Chart
    if not filtered_df.empty:
        geolocation_fig = px.scatter_mapbox(
            filtered_df, lat='location_lat', lon='location_long', hover_name='name',
            title='Geolocation of Selected Dog', zoom=12, height=600
        )
        geolocation_fig.update_layout(mapbox_style="open-street-map")
    else:
        geolocation_fig = go.Figure()
        geolocation_fig.add_annotation(text="No Data Available", showarrow=False, font=dict(size=20))
    
    # Secondary Chart (Breed Distribution for the selected dog or group)
    if not filtered_df.empty:
        secondary_fig = px.pie(filtered_df, names='breed', title='Breed Distribution', height=400)
    else:
        secondary_fig = go.Figure()
        secondary_fig.add_annotation(text="No Data Available", showarrow=False, font=dict(size=20))
    
    return geolocation_fig, secondary_fig



if __name__ == '__main__':
    app.run_server(debug=True)
