import pandas as pd

# Load the CSV data
df = pd.read_csv("animals.csv")

# Convert to JSON format as a single array
df.to_json("animals.json", orient="records", lines=False)