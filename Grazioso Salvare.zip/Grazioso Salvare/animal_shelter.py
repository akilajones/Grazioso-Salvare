from pymongo import MongoClient

class AnimalShelter:
    def __init__(self, username, password):
        self.client = MongoClient('mongodb://localhost:27017/')  # Adjust connection string if needed
        self.db = self.client['rescue_dogs_db']  # Access the database
        self.collection = self.db['dogs']  # Access the collection

    def create(self, data):
        """Insert a new document into the collection."""
        result = self.collection.insert_one(data)
        return str(result.inserted_id)

    def read(self, query):
        """Read documents from the collection based on a query."""
        return list(self.collection.find(query))

    def update(self, query, new_values):
        """Update documents in the collection based on a query."""
        result = self.collection.update_many(query, {'$set': new_values})
        return result.modified_count

    def delete(self, query):
        """Delete documents from the collection based on a query."""
        result = self.collection.delete_many(query)
        return result.deleted_count

    def close(self):
        """Close the MongoDB connection."""
        self.client.close() 